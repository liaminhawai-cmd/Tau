"""Numerical comparison at fixed poses, not a dynamics transfer certificate."""
import json
from pathlib import Path
import numpy as np
from scipy.optimize import minimize

HERE = Path(__file__).resolve().parent
trace = json.loads((HERE / 'diagnosis.json').read_text())['rows']
R = 23.095

def point(q, phi):
    e = np.array([np.cos(q['rot']), np.sin(q['rot']), 0.0])
    return np.array([q['x'], q['y'], 0.0]) + R*np.sin(phi)*e + np.array([0, 0, R*np.cos(phi)])

def tangent(q, phi):
    return R*np.array([np.cos(phi)*np.cos(q['rot']), np.cos(phi)*np.sin(q['rot']), -np.sin(phi)])

rows = []
for k in [72, 73, 74, 78, 80, 84, 98]:
    t = trace[k-1]
    for stage in ['pre', 'post']:
        a, v = t['att'], t[stage]
        def fun(x):
            w = point(v,x[1])-point(a,x[0])
            return .5*np.dot(w,w), np.array([-np.dot(w,tangent(a,x[0])),np.dot(w,tangent(v,x[1]))])
        sols = []
        for aa in np.linspace(0,np.pi/2,7):
            for vv in np.linspace(0,np.pi/2,7):
                z = minimize(fun,[aa,vv],jac=True,bounds=[(0,np.pi/2)]*2,method='L-BFGS-B',
                             options={'ftol':1e-15,'gtol':1e-10,'maxiter':200})
                sols.append(z)
        best = min(sols,key=lambda z:z.fun)
        w = point(v,best.x[1])-point(a,best.x[0]); n = w/np.linalg.norm(w)
        poly = t[stage+'Geom']; pn = np.array(poly['n'])
        rows.append({'k':k,'stage':stage,'phiA':float(np.degrees(best.x[0])),
                     'phiV':float(np.degrees(best.x[1])),'distance':float(np.linalg.norm(w)),
                     'polyPhiV':poly['phiV'],'polyDistance':poly['best']['dist'],
                     'normalAngleDeg':float(np.degrees(np.arccos(np.clip(np.dot(n,pn),-1,1)))),
                     'stationarityResidual':float(np.linalg.norm(fun(best.x)[1])),
                     'startCount':len(sols),'bestStartCount':int(sum(abs(z.fun-best.fun)<1e-8 for z in sols))})
(HERE/'smooth-arc.json').write_text(json.dumps(rows,indent=2)+'\n')
for r in rows: print(r)
