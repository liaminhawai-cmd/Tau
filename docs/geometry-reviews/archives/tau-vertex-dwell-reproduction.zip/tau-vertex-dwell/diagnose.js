const fs=require('fs'),path=require('path'),Module=require('module');
const repo=path.resolve(__dirname,'repo'),file=path.join(repo,'nn/throw-cert.js');
function loadChecker(patch=s=>s){const m=new Module(file);m.filename=file;m.paths=Module._nodeModulePaths(path.dirname(file));let s=fs.readFileSync(file,'utf8');
 s=s.replace('module.exports = { certify, analyse, sweep, pushSubstep, LIM_SUB };','module.exports = { certify, analyse, sweep, pushSubstep, LIM_SUB, arcPts, segClosest3, pairDist, rotAbout, aabbOf, matVecIv, hessBound };');
 s=s.replace('const pre = analyse(aabbOf(qc, M, U), att, pair);','const preBox = aabbOf(qc,M,U); const pre = analyse(preBox, att, pair); if(opts.onPre) opts.onPre({k,preBox,pre,qc,M,U});');
 s=s.replace('post = analyse(aabbOf(qcNext, M, Un), att, pair);','post = analyse(aabbOf(qcNext, M, Un), att, pair); if(opts.onRound) opts.onRound({k,round,grp,post,Un,Lam});');
 m._compile(patch(s),file);return m.exports;}
const TC=loadChecker(),CL=require('./repo/nn/contact-law.js'),FW=require('./repo/nn/forced-win.js');
const pieces=JSON.parse(fs.readFileSync(__dirname+'/pieces.json')),R=CL.R,D=CL.MIND,DEG=Math.PI/180;
const tr=TC.sweep(pieces,1,0,-1,138);
const vec=(p,q)=>[q.x-p.x,q.y-p.y,q.h-p.h],dot=(a,b)=>a.reduce((s,x,i)=>s+x*b[i],0),unit=a=>{const l=Math.hypot(...a);return a.map(x=>x/l);};
function geom(att,q){const A=TC.arcPts(att,0),V=TC.arcPts(q,0),pairs=[];for(let a=0;a<12;a++)for(let b=0;b<12;b++){const c=TC.segClosest3(A[a],A[a+1],V[b],V[b+1]);pairs.push({a,b,...c});}pairs.sort((a,b)=>a.dist-b.dist);const best=pairs[0],n=unit(vec(best.pa,best.pb));
 const vertex=V[4],a0=A[best.a],a1=A[best.a+1],a=unit(vec(a0,a1)),v=vec(a0,vertex),s=dot(v,a),ell=Math.hypot(...vec(a0,a1)),point={x:a0.x+s*a[0],y:a0.y+s*a[1],h:a0.h+s*a[2]},w=vec(point,vertex),dn=Math.hypot(...w),nv=w.map(x=>x/dn),bm=unit(vec(V[3],V[4])),bp=unit(vec(V[4],V[5]));
 return{best,pairs:pairs.slice(0,8),phiA:(best.a+best.s)*7.5,phiV:(best.b+best.t)*7.5,n,hf:Math.hypot(n[0],n[1]),rn:((best.pb.x-q.x)*n[1]-(best.pb.y-q.y)*n[0])/Math.hypot(n[0],n[1]),parkCandidate:{a:best.a,s,ell,d:dn,n:nv,w,dotBefore:dot(nv,bm),dotAfter:dot(nv,bp)}};
}
function describe(A){return{refuse:A.refuse,pad:A.pad,psi:A.psiN?.map(x=>x/DEG),hf:A.hf,rn:A.rn,regimes:A.segPairs?.map(s=>({a:s.a,b:s.b,vertex:s.vertex||null,psi:s.psiN.map(x=>x/DEG),rn:s.rn,why:s.why}))};}
if (require.main === module) {
const rows=[],pointChecks=[];
for(let k=1;k<=138;k++){const st=tr[k-1],pre=k===1?pieces[0]:tr[k-2].pose,pr=geom(st.att,pre),po=geom(st.att,st.pose);rows.push({k,deg:k/3,att:st.att,pre,post:st.pose,pushes:st.pushes.length,maxFootR:st.maxFootR,preGeom:pr,postGeom:po});
 if([31,32,33,70,71,72,73,74,75,80,84,98,99,110,138].includes(k)){const pp={x:[pre.x,pre.x],y:[pre.y,pre.y],rot:[pre.rot,pre.rot]};pointChecks.push({k,which:'pre',actual:pr,analyse:describe(TC.analyse(pp,st.att))});const pq={x:[st.pose.x-1e-12,st.pose.x+1e-12],y:[st.pose.y-1e-12,st.pose.y+1e-12],rot:[st.pose.rot-1e-12,st.pose.rot+1e-12]};pointChecks.push({k,which:'post',actual:po,analyse:describe(TC.analyse(pq,st.att,[0,0]))});}
}
const calls=[];let box;const h=.001,hr=h*4*DEG,v=pieces[0];box={x:[v.x-h,v.x+h],y:[v.y-h,v.y+h],rot:[v.rot-hr,v.rot+hr]};
const res=TC.certify(pieces,1,0,-1,box,1,{onPre:o=>{if(o.k>=68)calls.push({stage:'pre',k:o.k,box:o.preBox,...describe(o.pre)});},onRound:o=>{if(o.k>=71)calls.push({stage:'round',k:o.k,round:o.round,group:o.grp.psiN.map(x=>x/DEG),...describe(o.post)});}});
fs.writeFileSync(__dirname+'/diagnosis.json',JSON.stringify({rows,pointChecks,calls,failure:res.why},null,2));
console.log('failed',res.why);console.log('point checks',pointChecks.filter(r=>r.which==='pre').map(r=>({k:r.k,phiA:r.actual.phiA,phiV:r.actual.phiV,actualBearing:Math.atan2(r.actual.n[1],r.actual.n[0])/DEG,reported:r.analyse.psi,regimes:r.analyse.regimes?.map(p=>[p.a,p.b,p.vertex,p.psi])})));
console.log('park pre range',rows.filter(r=>Math.abs(r.preGeom.phiV-30)<1e-8).map(r=>r.k));
console.log('park post range',rows.filter(r=>Math.abs(r.postGeom.phiV-30)<1e-8).map(r=>r.k));
console.log('first throw',tr.find(r=>r.maxFootR>CL.EDGE)?.k,'last margin',tr.at(-1).maxFootR-CL.EDGE);
}
module.exports={loadChecker,geom,describe,TC,CL,FW,pieces};
