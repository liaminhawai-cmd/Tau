'use strict';
// Diagnostic implementations of the formulas in the report. Floating-point
// arithmetic here is not directed-rounding interval arithmetic.
const dot=(a,b)=>a.reduce((s,x,i)=>s+x*b[i],0);
const sub=(a,b)=>a.map((x,i)=>x-b[i]);
const norm=a=>Math.hypot(...a);
const xyz=p=>[p.x,p.y,p.h];
function vertexContact(a0,a1,pose,R,phi=Math.PI/6,leg=0) {
  const A0=xyz(a0),t=sub(xyz(a1),A0),ell=norm(t),a=t.map(x=>x/ell);
  const psi=pose.rot+leg*2*Math.PI/3,rho=R*Math.sin(phi);
  const r=[rho*Math.cos(psi),rho*Math.sin(psi)];
  const p=[pose.x+r[0],pose.y+r[1],R*Math.cos(phi)];
  const s=dot(sub(p,A0),a),sc=Math.max(0,Math.min(ell,s));
  const foot=A0.map((x,i)=>x+sc*a[i]),w=sub(p,foot),d=norm(w),h=Math.hypot(w[0],w[1]);
  const n=w.map(x=>x/d),nh=[w[0]/h,w[1]/h];
  return {a,ell,s,interior:s>0&&s<ell,r,p,foot,w,d,n,nh,hf:h/d,rn:r[0]*nh[1]-r[1]*nh[0]};
}
function cone(d,hf,delta) {
  if(!(delta<d*hf)) return {valid:false};
  const alpha=Math.asin(delta/d),beta=Math.asin(delta/(d*hf));
  return {valid:true,alpha,beta,normalError:2*Math.sin(alpha/2)};
}
function vertexGuards(c,bBefore,bAfter,delta,theta) {
  const e=delta+2*c.d*Math.sin(theta/2);
  return {sLo:c.s-delta,sHi:c.s+delta,beforeUpper:dot(c.w,bBefore)+e,
    afterLower:dot(c.w,bAfter)-e,error:e,
    localPark:c.s-delta>=0&&c.s+delta<=c.ell&&dot(c.w,bBefore)+e<=0&&dot(c.w,bAfter)-e>=0};
}
module.exports={vertexContact,cone,vertexGuards,dot,sub,norm,xyz};
