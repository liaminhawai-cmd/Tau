import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

HERE=Path(__file__).resolve().parent
OUT=HERE/'figures';OUT.mkdir(exist_ok=True)
rows=json.loads((HERE/'diagnosis.json').read_text())['rows']
checks=json.loads((HERE/'checks.json').read_text())
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,
 'axes.spines.right':False,'axes.labelcolor':'#334155','text.color':'#243247',
 'axes.edgecolor':'#cbd5e1','xtick.color':'#526174','ytick.color':'#526174',
 'svg.fonttype':'none','savefig.facecolor':'white'})
fig,axes=plt.subplots(1,2,figsize=(12,4.5),gridspec_kw={'width_ratios':[1.1,1]},layout='constrained')
for ax,(lo,hi) in zip(axes,[(23,28.4),(28,35.4)]):
 ss=[r for r in rows if lo<=r['deg']<=hi]
 ax.axhline(30,color='#78909c',ls='--',lw=1,label='Victim vertex')
 ax.plot([r['deg'] for r in ss],[r['preGeom']['phiV'] for r in ss],'-o',ms=4,lw=2,color='#156f95',label='Before push')
 ax.plot([r['deg'] for r in ss],[r['postGeom']['phiV'] for r in ss],'-s',ms=4,lw=2,color='#c06532',label='After push')
 ax.set_xlabel('Attacker sweep (degrees)');ax.set_xlim(lo,hi);ax.grid(axis='y',alpha=.15)
axes[0].set_ylabel('Victim contact angle (degrees)')
axes[0].axvline(28,color='#374151',ls=':',lw=1.3)
axes[0].set_title('A park at the start can end during the push',loc='left',fontsize=12,pad=16)
axes[0].annotate('First nominal throw',xy=(28,30.04),xytext=(26.1,30.40),fontsize=10,
 arrowprops={'arrowstyle':'->','color':'#526174'})
axes[1].set_title('The continued diagnostic sweep leaves the vertex',loc='left',fontsize=12,pad=16)
axes[1].text(.03,.05,'After the game would already have ended',transform=axes[1].transAxes,fontsize=9,color='#637386')
handles,labels=axes[0].get_legend_handles_labels();fig.legend(handles,labels,loc='outside lower center',ncol=3,frameon=False)
fig.savefig(OUT/'park-timing.svg');fig.savefig(OUT/'park-timing.png',dpi=160);plt.close(fig)

fig,ax=plt.subplots(figsize=(11,3.5),layout='constrained')
for y,s in enumerate(checks['singleton']):
 lo,hi=s['reportedBearing'];ax.plot([lo,hi],[y,y],color='#c06532',lw=8,solid_capstyle='round',alpha=.65)
 ax.plot(s['exactBearing'],y,'o',color='#156f95',ms=10,zorder=5)
 ax.text(hi+.16,y,f'{hi-lo:.2f}° width',va='center',fontsize=10)
ax.set_yticks(range(3),[f"Step {s['k']}" for s in checks['singleton']]);ax.invert_yaxis()
ax.set_xlim(-113,-100.3);ax.set_ylim(2.5,-.5);ax.set_xlabel('Horizontal contact-normal bearing (degrees)')
ax.set_title('An artificial cone remains even when the pose set is a single point',loc='left',fontsize=13,pad=18)
ax.plot([],[],color='#c06532',lw=7,alpha=.65,label='Current analyse() enclosure, zero pose uncertainty')
ax.plot([],[],'o',color='#156f95',ms=8,label='Unique geometric normal')
ax.legend(loc='upper center',bbox_to_anchor=(.5,-.25),ncol=2,frameon=False,fontsize=10);ax.grid(axis='x',alpha=.15)
fig.savefig(OUT/'singleton-cones.svg');fig.savefig(OUT/'singleton-cones.png',dpi=160);plt.close(fig)
print('Wrote two figures.')
