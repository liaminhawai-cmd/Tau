'use strict';
const fs=require('fs'),path=require('path'),Module=require('module');
const {TC,CL,pieces}=require('./diagnose.js');
const {vertexContact,cone,vertexGuards,sub,norm,xyz}=require('./vertex-bounds.js');
const trace=JSON.parse(fs.readFileSync(path.join(__dirname,'diagnosis.json'))).rows;
const ef=path.resolve(__dirname,'repo/nn/engine.js'),em=new Module(ef);
em.filename=ef;em.paths=Module._nodeModulePaths(path.dirname(ef));
em._compile(fs.readFileSync(ef,'utf8').replace('CFG, Piece, radU, norm,','CFG, Piece, radU, norm, resolvePush,'),ef);
const engine=em.exports.createEngine();
const R=CL.R,theta=.024/R,delta=.024,unit=v=>v.map(x=>x/norm(v));
const out={constants:{R,H:engine.CFG.hubHeight,I:CL.I,D:CL.MIND,EDGE:CL.EDGE},engineChecks:[],bounds:[],singleton:[]};
let maxError=0;
for(const row of trace) {
  const a=Object.assign(new engine.Piece(1),row.att),q=Object.assign(new engine.Piece(0),row.pre);
  engine.resolvePush(a,q);
  const err=Math.hypot(q.x-row.post.x,q.y-row.post.y,R*(q.rot-row.post.rot));maxError=Math.max(maxError,err);
  if([32,73,74,78,79,80,81,82,84,98,99,105,138].includes(row.k))out.engineChecks.push({k:row.k,err,pose:{x:q.x,y:q.y,rot:q.rot}});
  if([73,74,75,78,79,80,81,82,83,84,98,99].includes(row.k))for(const stage of ['pre','post']) {
    const q=row[stage],g=row[stage+'Geom'],A=TC.arcPts(row.att,0),V=TC.arcPts(q,0),ai=g.best.a;
    const c=vertexContact(A[ai],A[ai+1],q,R),b0=unit(sub(xyz(V[4]),xyz(V[3]))),b1=unit(sub(xyz(V[5]),xyz(V[4])));
    const guards=vertexGuards(c,b0,b1,delta,theta),angles=cone(c.d,c.hf,delta);
    let competitor=Infinity;
    for(let i=0;i<12;i++)for(let j=0;j<12;j++)if(!(i===ai&&(j===3||j===4))) {
      competitor=Math.min(competitor,TC.segClosest3(A[i],A[i+1],V[j],V[j+1]).dist);
    }
    out.bounds.push({k:row.k,stage,phiV:g.phiV,c,guards,cone:angles,competitorGap:competitor-c.d,
      legPairGlobalGapLower:competitor-c.d-2*delta});
  }
}
out.engineMaximumError=maxError;
for(const k of [74,80,84]) {
 const r=trace[k-1],q=r.pre,A=TC.arcPts(r.att,0),c=vertexContact(A[1],A[2],q,R);
 const exact=TC.analyse({x:[q.x,q.x],y:[q.y,q.y],rot:[q.rot,q.rot]},r.att);
 out.singleton.push({k,exactBearing:Math.atan2(c.n[1],c.n[0])*180/Math.PI,
   reportedBearing:exact.psiN.map(x=>x*180/Math.PI),reportedHf:exact.hf,reportedRn:exact.rn,
   geometricHf:c.hf,geometricRn:c.rn});
}
// Finite checks of the analytic cone and KKT sufficient condition. These checks
// verify the implementation on a grid; the report supplies the proofs.
out.gridChecks=[];
for(const k of [74,82,84]) {
 const row=trace[k-1],q=row.pre,A=TC.arcPts(row.att,0),center=vertexContact(A[1],A[2],q,R);
 const h=.008,hr=.008/R,deltav=Math.SQRT2*h+R*Math.sin(hr/2),co=cone(center.d,center.hf,deltav);
 let max3=0,maxH=0,maxW=0,park=0,total=0,err=0;
 for(let i=-4;i<=4;i++)for(let j=-4;j<=4;j++)for(let t=-4;t<=4;t++) {
   const qq={...q,x:q.x+i*h/4,y:q.y+j*h/4,rot:q.rot+t*hr/4},c=vertexContact(A[1],A[2],qq,R);
   const diff=Math.hypot(...c.n.map((v,i)=>v-center.n[i]));
   const db=Math.acos(Math.max(-1,Math.min(1,c.nh[0]*center.nh[0]+c.nh[1]*center.nh[1])));
   max3=Math.max(max3,2*Math.asin(Math.min(1,diff/2)));maxH=Math.max(maxH,db);maxW=Math.max(maxW,norm(sub(c.w,center.w)));
   const V=TC.arcPts(qq,0);let best=Infinity,bt;
   for(let a=0;a<12;a++)for(let b=0;b<12;b++){const cc=TC.segClosest3(A[a],A[a+1],V[b],V[b+1]);if(cc.dist<best){best=cc.dist;bt=(b+cc.t)*7.5;}}
   if(Math.abs(bt-30)<1e-8)park++;total++;
   if(diff>co.normalError+1e-12||db>co.beta+1e-12||norm(sub(c.w,center.w))>deltav+1e-12)err++;
 }
 out.gridChecks.push({k,h,hr,deltav,cone:co,max3,maxH,maxW,park,total,violations:err});
}
out.sagitta=[12,24,48].map(N=>({N,chord:2*R*Math.sin(Math.PI/(4*N)),sag:R*(1-Math.cos(Math.PI/(4*N)))}));
out.referenceCone=cone(2.88,.554,.024);
out.vertexNewton=[];
for(const k of [74,80,84]) {
 const row=trace[k-1],A=TC.arcPts(row.att,0),c=vertexContact(A[1],A[2],row.pre,R);
 const rho=R/2,pv=Math.sqrt(1+rho*rho/CL.I),penetration=CL.MIND-c.d;
 const m=c.hf*Math.sqrt(1+c.rn*c.rn/CL.I),massStep=penetration/m;
 const dLo=c.d-pv*massStep,M=pv*pv/dLo+rho/CL.I;
 out.vertexNewton.push({k,penetration,m,massStep,dLo,M,overshoot:M*massStep*massStep/2,
   actualGlobalOvershoot:row.postGeom.best.dist-CL.MIND});
}
fs.writeFileSync(path.join(__dirname,'checks.json'),JSON.stringify(out,null,2));
console.log(JSON.stringify({engineMaximumError:maxError,singleton:out.singleton,
  bounds:out.bounds.map(b=>({k:b.k,stage:b.stage,localPark:b.guards.localPark,globalGap:b.legPairGlobalGapLower})),
  gridChecks:out.gridChecks,sagitta:out.sagitta,referenceCone:out.referenceCone},null,2));
if(maxError>1e-9||out.gridChecks.some(x=>x.violations))process.exitCode=1;
