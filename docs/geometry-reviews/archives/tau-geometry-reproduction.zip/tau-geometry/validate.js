const fs=require('fs'),F=require('./source/forced-win.js'),C=require('./source/contact-law.js');
const data=JSON.parse(fs.readFileSync(__dirname+'/geometry-data.json'));
let seed=270918;const rand=()=>((seed=(1664525*seed+1013904223)>>>0)/4294967296);
const checks=[];
for(let z=0;z<12;z++){
 const p=F.piecesOf(data.poses[0].p);p[0].x+=3*rand()-1.5;p[0].y+=3*rand()-1.5;p[0].rot+=(3*rand()-1.5)/C.R;
 for(const a of data.arms){const e=F.limitAt(p,0,a.p,a.dir),l=F.limitLadder(p,0,a.p,a.dir);checks.push({sample:z,pose:p[0],...a,error:Math.abs(e.lim-l.lim),signatureMatch:e.sig===l.sig});}
}
let drift=0;const q=F.piecesOf(data.poses[0].p)[0];
for(let p=0;p<3;p++){
 const P=C.feetOf(q)[p];const ref=F.limitEvents(C.feetOf(q),p,1);const ek=e=>[e.foot,e.circle,e.kind,e.D??e.A,e.sign].join(':');const rmap=new Map(ref.map(e=>[ek(e),e.s+q.rot]));
 for(const t of [-3,-1.5,.75,3]){const rot=q.rot+t/C.R;const qq={x:P.x-C.R*Math.cos(rot+p*2*Math.PI/3),y:P.y-C.R*Math.sin(rot+p*2*Math.PI/3),rot};for(const e of F.limitEvents(C.feetOf(qq),p,1)){const a=e.s+rot-rmap.get(ek(e));drift=Math.max(drift,Math.abs(Math.atan2(Math.sin(a),Math.cos(a))));}}
}
const out={checks,maxError:Math.max(...checks.map(x=>x.error)),allSignaturesMatch:checks.every(x=>x.signatureMatch),pivotPhaseMaxErrorRadians:drift};
fs.writeFileSync(__dirname+'/validation.json',JSON.stringify(out,null,2));console.log({maxError:out.maxError,allSignaturesMatch:out.allSignaturesMatch,pivotPhaseMaxErrorRadians:drift});
