"""Summarize uploaded result logs without treating retries as new positions."""
from pathlib import Path
from collections import Counter,defaultdict
import json,sys,hashlib,csv,math,statistics
BASE=Path(__file__).resolve().parent
src=Path(sys.argv[1]) if len(sys.argv)>1 else BASE.parent/'upload'
def read(name):return [json.loads(s) for s in (src/name).read_text().splitlines() if s.strip()]
dead=read('dead1.jsonl');deep=read('deep2.jsonl');seeds=read('seeds-k4-childdead.jsonl')
def key(r):return (r['file'],r['g'],r['k'],r['mover'],tuple(r['p']))
groups=defaultdict(list)
for r in deep:groups[key(r)].append(r)
latest=[max(v,key=lambda r:r['stamp']) for v in groups.values()]
seedkeys={key(r) for r in seeds};proper=[r for r in latest if key(r) in seedkeys];extra=[r for r in latest if key(r) not in seedkeys]
children={(r['file'],r['g'],r['mover']) for r in dead if r['status']=='dead' and r['k']==2}
linked=sum((r['file'],r['g'],r['mover']) in children for r in seeds)
positive=[r for r in latest if r['certified']]
for r in positive:
 for w in r.get('witnesses',[]):
  w['degrees']={k:w[k]*180/math.pi for k in ['from','to','aFrom','aTo']}
summary={'inputs':{name:{'sha256':hashlib.sha256((src/name).read_bytes()).hexdigest(),'bytes':(src/name).stat().st_size} for name in ['dead1.jsonl','deep2.jsonl','seeds-k4-childdead.jsonl','tally.txt']},'dead1':{'rows':len(dead),'unique':len({key(r) for r in dead}),'status':dict(Counter(r['status'] for r in dead))},'deep2':{'rows':len(deep),'unique':len(latest),'retryRows':len(deep)-len(latest),'status':dict(Counter(r['status'] for r in latest)),'proper':dict(Counter(r['status'] for r in proper)),'extra':dict(Counter(r['status'] for r in extra))},'seeds':{'count':len(seeds),'linkedToDeadChildByGameFileAndMover':linked},'certified':positive,'unresolved':[{'file':r['file'],'p':r['p'],'mover':r['mover'],'why':r['why']} for r in latest if r['status']=='unresolved']}
(BASE/'search-results-summary.json').write_text(json.dumps(summary,indent=2))
with (BASE/'deep2-latest.csv').open('w') as f:
 names=['file','g','mover','cohort','status','certified','worstMargin','seconds','stamp','p','why'];w=csv.DictWriter(f,fieldnames=names);w.writeheader()
 for r in latest:w.writerow({**{k:r.get(k) for k in names if k!='cohort'},'cohort':'child-dead seed' if key(r) in seedkeys else 'extra','p':json.dumps(r['p'])})
print(json.dumps({k:v for k,v in summary.items() if k not in ['inputs','unresolved','certified']},indent=2));print('positive witnesses',positive[0]['witnesses'] if positive else None)
