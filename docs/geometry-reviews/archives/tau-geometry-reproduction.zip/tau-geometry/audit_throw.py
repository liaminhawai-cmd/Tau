"""Reproducible algebra checks for the uploaded throw-theorem.md."""
import math,json
from pathlib import Path
R=23.095;I=.7*R*R
def update(r,n,s,F):
 rn=r[0]*n[1]-r[1]*n[0];lam=s/(1+rn*rn/I);e=lam*rn/I
 rot=lambda v:(math.cos(e)*v[0]-math.sin(e)*v[1],math.sin(e)*v[0]+math.cos(e)*v[1])
 rr=rot(r);dp=(lam*n[0]+rr[0]-r[0],lam*n[1]+rr[1]-r[1]);eta=s-sum(a*b for a,b in zip(dp,n))
 return dict(r=r,n=n,s=s,rn=rn,lam=lam,e=e,eta=eta,normalDisplacement=s-eta)
# Valid horizontal contact-point coordinates, inside the leg's radius bound.
lemma1=update((-R/math.sqrt(2),R/math.sqrt(2)),(1,0),.8,None)
# Finite contact motion: tangential advance changes penetration even for two points.
D=2.88;a=.1;b=.2;separation=D-math.hypot(D-a,b)
# Explicit foot error: choose the spin-maximizing lever, a radial normal, and an
# exposed foot initially parallel to its radial direction. All algebraic bounds hold.
s=.32;rn=math.sqrt(I);lam=s/(1+rn*rn/I);e=lam*rn/I;r0=64
radial=math.hypot(r0+lam+R*(math.cos(e)-1),R*math.sin(e))-r0
linear=lam
attacker_step=2*math.sqrt(3)*R*math.sin(math.radians(.4)/2)
out={'R':R,'I':I,'lemma1_negative_deficit':lemma1,'finite_advance':{'D':D,'normal_advance':a,'tangential_advance':b,'actual_separation':separation,'advance_minus_separation':a-separation},'lemma3_error':{'s':s,'rn':rn,'lambda':lam,'spin':e,'initialFootRadius':r0,'linearRadialGain':linear,'exactRadialGain':radial,'error':radial-linear},'first_pass_if_initially_nonpenetrating':{'maximumAxisDisplacement':attacker_step,'separationUpperBoundUsingFloor':attacker_step/.35}}
p=Path(__file__).parent/'throw-audit-values.json';p.write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
