from geometry import *
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle,Rectangle,Arc
from matplotlib.lines import Line2D
import csv
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','axes.titleweight':'bold'})
OUT=BASE/'figures';OUT.mkdir(exist_ok=True)
COL={'A1':'#175bb5','A2':'#c46a13','A3':'#883fc0','A4':'#17845c','A5':'#d63345','A6':'#6b6f7b'}
CAT=json.loads((BASE/'wall-catalog.json').read_text())
def save(fig,name):
    fig.savefig(OUT/(name+'.svg'),bbox_inches='tight',facecolor='white')
    fig.savefig(OUT/(name+'.png'),dpi=170,bbox_inches='tight',facecolor='white')
    if name=='04-swing-geometry':fig.savefig(OUT/(name+'.jpg'),dpi=130,bbox_inches='tight',facecolor='white')
    plt.close(fig)
def extras(axv,seed,t):
    xx,yy=np.meshgrid(axv,axv);theta=seed[2]+t/R;x=seed[0]+xx;y=seed[1]+yy;fx,fy=feet(x,y,theta);out=[]
    for i in range(3):
        for ci,levels in enumerate(LEVELS):
            # A4 includes centreline side bits used by PR18, plus corner membership.
            fam='A5' if ci==4 else 'A4'
            for D in levels:
                z=np.hypot(fx[i]-CENTRES[ci,0],fy[i]-CENTRES[ci,1])-D
                if ci in (2,3):
                    bearing=np.mod(np.arctan2(fy[i]-CENTRES[ci,1],fx[i]-CENTRES[ci,0])-RAYS[ci][0],TAU)
                    z=np.where(bearing<=RAYS[ci][1]-RAYS[ci][0],z,np.nan)
                for seg in contours(axv,axv,z):out.append(dict(family=fam,label=f'f{i}:{NAMES[ci]} {D:g}',segments=[seg]))
            for A in RAYS.get(ci,[]):
                ux=fx[i]-CENTRES[ci,0];uy=fy[i]-CENTRES[ci,1]
                z=ux*np.sin(A)-uy*np.cos(A);z=np.where((ux*np.cos(A)+uy*np.sin(A)>=0)&(abs(np.hypot(ux,uy)-40)<.81),z,np.nan)
                for seg in contours(axv,axv,z):out.append(dict(family='A4',label=f'f{i}:{NAMES[ci]} span',segments=[seg]))
        # A2: all circle-event birth/death loci, even if behind the current stop.
        for ci,levels in enumerate(LEVELS):
            for D in levels:
                for rr in sorted(set([abs(D-RHO),D+RHO])):
                    z=np.hypot(fx[i]-CENTRES[ci,0],fy[i]-CENTRES[ci,1])-rr
                    for seg in contours(axv,axv,z):out.append(dict(family='A2',label=f'p{i}:{NAMES[ci]} tangent {rr:.3f}',segments=[seg]))
        # A2 of span support-lines: distance(P,line)=rho. Gating to the ray and band
        # can subsequently discard these raw analytic candidates.
        for ci,rs in RAYS.items():
            for A in rs:
                z=abs((fx[i]-CENTRES[ci,0])*np.sin(A)-(fy[i]-CENTRES[ci,1])*np.cos(A))-RHO
                for seg in contours(axv,axv,z):out.append(dict(family='A2',label=f'p{i}:{NAMES[ci]} ray tangent',segments=[seg]))
    return out
def boxes(ax,extent=1.5):
    for half,style in [(1,'--'),(.4,':')]:ax.add_patch(Rectangle((-half,-half),2*half,2*half,fill=False,edgecolor='#334155',linestyle=style,linewidth=1))
    ax.plot(0,0,'*',color='#17243b',ms=9,zorder=30)
    ax.set(xlim=(-extent,extent),ylim=(-extent,extent),aspect='equal',xlabel='Δx (u)',ylabel='Δy (u)');ax.grid(alpha=.13)
EXTRAS=[]
fig,axs=plt.subplots(2,3,figsize=(14,9.6),layout='constrained')
for si,(ax,g,sc) in enumerate(zip(axs.flat,DATA['grids'],CAT['slices'])):
    q=np.linspace(-1.5,1.5,g['n']);arr=np.array(g['rows'],dtype=object)
    multi=np.array([[any(len(v['events'])>1 for v in pt) for pt in row] for row in g['rows']])
    if multi.any():ax.contourf(q,q,multi,levels=[.5,1.5],colors=[COL['A6']],alpha=.2)
    ex=extras(np.linspace(-1.5,1.5,241),SEED,g['t']);EXTRAS.append(ex)
    for z in ex:
        for seg in z['segments']:ax.plot(seg[:,0],seg[:,1],color=COL[z['family']],ls='--' if z['family']=='A2' else '-',lw=1,alpha=.65 if z['family']=='A2' else .95)
    for w in sc['walls']:
        v=CAT['catalog'][w['key']]
        for seg in w['segments']:
            a=np.array(seg);ax.plot(a[:,0],a[:,1],color=COL['A1'],lw=1.9)
        a=np.array(max(w['segments'],key=len));m=a[len(a)//2]
        ax.annotate(v['id'],m,xytext=(4,4),textcoords='offset points',color=COL['A1'],fontsize=8,bbox={'facecolor':'white','edgecolor':'none','alpha':.85,'pad':1})
    # A3: analytic 2-degree level of each observed stopping event, clipped to
    # where that event is actually the stopping event in the engine grid.
    X,Y=np.meshgrid(np.linspace(-1.5,1.5,241),np.linspace(-1.5,1.5,241));axv=np.linspace(-1.5,1.5,241)
    ids=np.rint((X+1.5)/3*(g['n']-1)).astype(int);jds=np.rint((Y+1.5)/3*(g['n']-1)).astype(int)
    for k,arm in enumerate(DATA['arms']):
        for ek in set(e for row in g['rows'] for pt in row for e in pt[k]['events']):
            e=DATA['events'][ek];s=angle(e,SEED[0]+X,SEED[1]+Y,SEED[2]+g['t']/R,arm['p'],arm['dir'])/RAD
            active=np.array([[ek in pt[k]['events'] for pt in row] for row in g['rows']])[jds,ids]
            for seg in contours(axv,axv,np.where(active,s-2,np.nan)):
                ax.plot(seg[:,0],seg[:,1],color=COL['A3'],lw=2)
                m=seg[len(seg)//2];ax.annotate(f'A3 ({arm["p"]},{"+" if arm["dir"]>0 else "−"})',m,xytext=(4,0),textcoords='offset points',fontsize=7,color=COL['A3'])
    boxes(ax);ax.set_title(f't = {g["t"]:+.2f} u   (θ = θ₀ + t/R)')
ax=axs.flat[-1];ax.axis('off')
handles=[Line2D([0],[0],color=COL[f],lw=2,ls='--' if f=='A2' else '-',label=s) for f,s in [('A1','A1 · event-order equality'),('A2','A2 · event tangency candidates'),('A3','A3 · a reply falls below 2°'),('A4','A4 · start-contact / side state'),('A5','A5 · starting foot reaches rim'),('A6','A6 · >1 event in stopping bin (shading)')]]
ax.legend(handles=handles,loc='upper left',frameon=False,fontsize=10)
ax.text(.03,.49,'E01 · (0,−): f1 r1 outer = f2 a0 outer\nE02 · (2,−): f1 r1 outer = f1 a0 inner\nE03 · (2,−): f1 r0 outer = f1 a0 inner\nE04 · (2,−): f1 r1 inner = f1 a0 inner',transform=ax.transAxes,linespacing=1.8,fontsize=9)
ax.text(.03,.20,'★ Reference (x₀,y₀) on each slice; only t=0 is the seed.\nDashed square: ±1u. Dotted square: ±0.4u.\nOrange curves can concern events after the stop.\nBlue equalities are candidates, not dead-set boundaries.\nAll six arms inspected; 65×65 engine grid per slice.',transform=ax.transAxes,fontsize=8,linespacing=1.7)
fig.suptitle('The local limit arrangement is richer than one wall',fontsize=18,fontweight='bold')
save(fig,'01-wall-slices')
summary=[]
for g,ex in zip(DATA['grids'],EXTRAS):summary.append({'t':g['t'],'otherWalls':sorted(set(z['family']+' '+z['label'] for z in ex))})
(BASE/'additional-walls.json').write_text(json.dumps(summary,indent=2))

# Individually labeled slices accompany the overview: every extra candidate gets
# a stable ID so a reader can identify all curves without crowding the mosaic.
keys=sorted(set((z['family'],z['label']) for ex in EXTRAS for z in ex));counts={};extra_ids={}
for fam,lab in keys:
    counts[fam]=counts.get(fam,0)+1;extra_ids[(fam,lab)]=f'{fam}.{counts[fam]}'
(BASE/'extra-wall-ids.json').write_text(json.dumps([{'family':f,'label':l,'id':v} for (f,l),v in extra_ids.items()],indent=2))
for gi,(g,ex,sc) in enumerate(zip(DATA['grids'],EXTRAS,CAT['slices'])):
    fig,ax=plt.subplots(figsize=(8.5,7.7),layout='constrained');q=np.linspace(-1.5,1.5,g['n'])
    multi=np.array([[any(len(v['events'])>1 for v in pt) for pt in row] for row in g['rows']])
    if multi.any():ax.contourf(q,q,multi,levels=[.5,1.5],colors=[COL['A6']],alpha=.2)
    for ei,z in enumerate(ex):
        for a in z['segments']:ax.plot(a[:,0],a[:,1],color=COL[z['family']],ls='--' if z['family']=='A2' else '-',lw=1.4)
        a=max(z['segments'],key=len);m=a[int(len(a)*(.30+.10*(ei%4)))]
        tx=np.clip(m[0]+.07,-1.34,1.16);ty=np.clip(m[1]+.06,-1.34,1.30)
        ax.annotate(extra_ids[(z['family'],z['label'])],m,xytext=(tx,ty),color=COL[z['family']],fontsize=9,bbox={'facecolor':'white','edgecolor':'none','alpha':.85,'pad':1},arrowprops={'arrowstyle':'-','color':COL[z['family']],'lw':.5})
    for w in sc['walls']:
        d=CAT['catalog'][w['key']]
        for seg in w['segments']:a=np.array(seg);ax.plot(a[:,0],a[:,1],color=COL['A1'],lw=2)
        a=np.array(max(w['segments'],key=len));m=a[len(a)//2];ax.annotate(d['id'],m,xytext=(np.clip(m[0]-.2,-1.35,1.3),np.clip(m[1]-.13,-1.34,1.3)),color=COL['A1'],fontsize=10,bbox={'facecolor':'white','edgecolor':'none','pad':1})
    lim=np.array([[pt[4]['lim'] for pt in row] for row in g['rows']])
    if lim.min()<2<lim.max():ax.contour(q,q,lim,levels=[2],colors=[COL['A3']],linewidths=1.8)
    boxes(ax);ax.set_title(f'ndpxhts24 · labeled slice t = {g["t"]:+.2f}u',fontsize=15)
    fig.supxlabel('A3 (purple): arm (2,+) minimum-move transition. A6 (gray): shared stopping bins. IDs refer to the report table.',fontsize=8)
    save(fig,f'wall-slice-{gi+1}')

# Pivot coordinates: exact equality curves, extended throughout the plot, independent of theta.
fig,axs=plt.subplots(1,3,figsize=(14,5.3),layout='constrained')
for p,ax in enumerate(axs):
    P=SEED[:2]+R*np.array([np.cos(SEED[2]+OFF[p]),np.sin(SEED[2]+OFF[p])]);v=np.linspace(-3.1,3.1,361);xx,yy=np.meshgrid(v,v)
    for ci,lv in enumerate(LEVELS):
        for D in lv:
            for rr in [abs(D-RHO),D+RHO]:
                for seg in contours(v,v,np.hypot(P[0]+xx-CENTRES[ci,0],P[1]+yy-CENTRES[ci,1])-rr):
                    ax.plot(seg[:,0],seg[:,1],color=COL['A2'],lw=.9,ls='--',alpha=.7)
    for w in CAT['catalog'].values():
        if w['p']!=p:continue
        gg=phase(w['e'],P[0]+xx,P[1]+yy,p)-phase(w['f'],P[0]+xx,P[1]+yy,p)
        gg=np.angle(np.exp(1j*gg));gg=np.where(abs(gg)<.2,gg,np.nan)
        for seg in contours(v,v,gg):
            ax.plot(seg[:,0],seg[:,1],color=COL['A1'],lw=2);m=seg[len(seg)//2]
            ax.annotate(w['id'],m,xytext=(4,4),textcoords='offset points',color=COL['A1'],fontsize=9,bbox={'facecolor':'white','alpha':.8,'edgecolor':'none','pad':1})
    for t in [-1.5,-.75,0,.75,1.5]:
        shift=R*np.array([np.cos(SEED[2]+t/R+OFF[p])-np.cos(SEED[2]+OFF[p]),np.sin(SEED[2]+t/R+OFF[p])-np.sin(SEED[2]+OFF[p])])
        ax.add_patch(Rectangle(shift-1.5,3,3,fill=False,edgecolor='#94a3b8',lw=.75,alpha=.8))
    ax.plot(0,0,'*',color='#17243b',ms=10);ax.set(xlim=(-3.1,3.1),ylim=(-3.1,3.1),aspect='equal',xlabel='ΔPₓ (u)',ylabel='ΔPᵧ (u)',title=f'Pivot {p} · both directions')
    ax.grid(alpha=.13)
    if p==1:ax.text(.04,.04,'No pre-stop A1 equality found\nin the requested slices.',transform=ax.transAxes,fontsize=9,bbox={'facecolor':'white','edgecolor':'none'})
fig.suptitle('Pivot coordinates remove θ from A1 and A2; each pivot needs its own chart',fontsize=16,fontweight='bold')
fig.supxlabel('Gray squares: the five ±1.5u hub slices mapped into this pivot plane. Orange: circle tangencies, including inactive candidates.',fontsize=9)
save(fig,'02-pivot-planes')

# All-arm phase atlas: one third-degree limit contours and co-event bins.
fig,axs=plt.subplots(6,5,figsize=(14,17),layout='constrained')
for k,arm in enumerate(DATA['arms']):
 for gi,g in enumerate(DATA['grids']):
    ax=axs[k,gi];q=np.linspace(-1.5,1.5,g['n']);lim=np.array([[pt[k]['lim'] for pt in row] for row in g['rows']]);multi=np.array([[len(pt[k]['events'])>1 for pt in row] for row in g['rows']]);
    ax.contour(q,q,lim,levels=np.arange(np.floor(lim.min()*3)/3,lim.max()+1/3,1/3),colors='#aeb8c5',linewidths=.42)
    if multi.any():ax.contourf(q,q,multi,levels=[.5,1.5],colors=[COL['A6']],alpha=.5)
    if lim.min()<2<lim.max():ax.contour(q,q,lim,levels=[2],colors=[COL['A3']],linewidths=1.4)
    for w in CAT['slices'][gi]['walls']:
        d=CAT['catalog'][w['key']]
        if d['p']==arm['p'] and d['dir']==arm['dir']:
            for seg in w['segments']:a=np.array(seg);ax.plot(a[:,0],a[:,1],color=COL['A1'],lw=1.3)
    boxes(ax);ax.set_xlabel('');ax.set_ylabel('')
    ax.tick_params(labelsize=6)
    if gi==0:ax.set_ylabel(f'({arm["p"]},{"+" if arm["dir"]>0 else "−"})\nΔy (u)')
    if k==0:ax.set_title(f't = {g["t"]:+g}u',fontsize=10)
fig.suptitle('All six reply arms · quantized limits and shared stopping bins',fontsize=17,fontweight='bold')
fig.supxlabel('Gray contours: 1/3° changes of the sampled limit. Dark gray: multiple tagged events in one stopping bin. Blue: analytic A1 candidates.',fontsize=9)
save(fig,'03-phase-atlas')

# Swing illustration and full event timeline, with geometric root checks.
def board(ax):
    ax.add_patch(Circle((0,0),66.667,facecolor='#f8fafc',edgecolor='#24364b',lw=1.2))
    ax.add_patch(Circle((0,0),67.167,fill=False,edgecolor='#d63345',lw=.8,ls='--'))
    for r in [40,53.3]:
        ax.add_patch(Circle((0,0),r,fill=False,edgecolor='#8aa0b4',lw=.8));ax.add_patch(plt.matplotlib.patches.Wedge((0,0),r+.81,0,360,width=1.62,facecolor='#8aa0b4',alpha=.22))
    for ci in [2,3]:
        cx,cy=CENTRES[ci];lo,hi=RAYS[ci]/RAD
        ax.add_patch(plt.matplotlib.patches.Wedge((cx,cy),40.81,lo,hi,width=1.62,facecolor='#8aa0b4',alpha=.25));ax.add_patch(Arc((cx,cy),80,80,theta1=lo,theta2=hi,edgecolor='#60768e',lw=.8))
        for a in RAYS[ci]:ax.plot([cx,cx+42*np.cos(a)],[cy,cy+42*np.sin(a)],color='#88939f',lw=.6,ls=':')
    for ci in range(5,13):ax.add_patch(Circle(CENTRES[ci],.81,facecolor='#c46a13',alpha=.6))
    ax.set(xlim=(-74,74),ylim=(-74,74),aspect='equal',xlabel='x (u)',ylabel='y (u)');ax.grid(alpha=.08)
blue,red=DATA['poses'][0]['feet'];P=np.array([blue[0]['x'],blue[0]['y']]);theta=SEED[2];lim=DATA['poses'][0]['limits'][1]['lim'];rows=[]
for ix,e in enumerate(DATA['swingEvents']):
    s=e['s'];i=e['foot'];pos=P+RHO*np.array([np.cos(theta+delta(i,0)-s),np.sin(theta+delta(i,0)-s)]);ci=e['circle'];u=pos-CENTRES[ci]
    residual=abs(np.hypot(*u)-e['D']) if e['kind']=='level' else abs(u[0]*np.sin(e['A'])-u[1]*np.cos(e['A']))
    forward=bool(u[0]*np.cos(e['A'])+u[1]*np.sin(e['A'])>=0) if e['kind']=='ray' else None
    physical_here=bool(physical(e,np.array(P[0]),np.array(P[1]),0));rows.append({'id':f'S{ix+1:02d}','foot':i,'circle':NAMES[ci],'kind':e['kind'],'level_or_ray':e.get('D',e.get('A',0)/RAD),'root_sign':e['sign'],'degrees':s/RAD,'x':pos[0],'y':pos[1],'residual_u':residual,'forward_ray':forward,'input_relevant':physical_here,'before_stop':s/RAD<=lim+1/3})
with (BASE/'swing-events.csv').open('w') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
fig=plt.figure(figsize=(15,9.5),layout='constrained');gs=fig.add_gridspec(2,2,width_ratios=[1.25,1],height_ratios=[1,1]);ax=fig.add_subplot(gs[:,0]);board(ax)
for j,ff in enumerate([blue,red]):
    hub=SEED[:2] if j==0 else np.array(DATA['poses'][0]['p'][3:5]);color=['#175bb5','#d94d60'][j]
    for i,foot in enumerate(ff):ax.plot([hub[0],foot['x']],[hub[1],foot['y']],color=color,lw=1.8,alpha=.75);ax.plot(foot['x'],foot['y'],'o',ms=5,color=color)
    ax.plot(*hub,'o',color=color,ms=5)
ax.add_patch(Circle(P,RHO,fill=False,color='#596376',lw=.8,ls='--'));ax.add_patch(Circle(P,R,fill=False,color='#848d9b',lw=.8,ls=':'))
for i,color in [(1,'#175bb5'),(2,'#7941c9')]:
    ss=np.linspace(0,lim*RAD,300);ph=theta+delta(i,0)-ss;xy=P[:,None]+RHO*np.array([np.cos(ph),np.sin(ph)])
    ax.plot(*xy,color=color,lw=2.4);ax.annotate('',xy=xy[:,110],xytext=xy[:,93],arrowprops={'arrowstyle':'->','color':color,'lw':2})
    st=np.array([blue[i]['x'],blue[i]['y']]);ax.annotate(f'f{i} · 0°',st,xytext=(-26,-15),textcoords='offset points',fontsize=9,color=color)
    en=xy[:,-1];ax.plot(*en,'s',color=color,ms=5);ax.annotate(f'f{i} · {lim:.2f}°',en,xytext=(7,4 if i==2 else -13),textcoords='offset points',fontsize=9,color=color)
for row in rows:
    if row['input_relevant']:ax.plot(row['x'],row['y'],'o',mfc='white',mec='#6e7c91',ms=3,zorder=4)
ax.plot(*P,'*',color='#132338',ms=13,zorder=8);ax.annotate('P = f0\n(−19.14, −14.84)',P,xytext=(8,8),textcoords='offset points',fontsize=9)
ax.text(.02,.97,'Both moving feet share one radius-40 circle.\nTheir event clocks differ by 60°.',transform=ax.transAxes,va='top',fontsize=10,bbox={'facecolor':'white','edgecolor':'none','alpha':.9})
ax.set_title('Clockwise swing (0,−) at ndpxhts24')
for ai,(lo,hi,title) in enumerate([(0,75,'The legal swing and its stopping event'),(0,360,'Complete 360° geometric candidate list')]):
    bx=fig.add_subplot(gs[ai,1]);lane={'r0':0,'r1':1,'a0':2,'a1':3,'rim':4};
    for row in rows:
        if not lo<=row['degrees']<=hi:continue
        y0=lane.get(row['circle'],5)+(.13 if row['foot']==1 else -.13);color='#175bb5' if row['foot']==1 else '#7941c9';mk='|' if row['input_relevant'] else 'x'
        bx.scatter(row['degrees'],y0,c=color,marker=mk,s=75 if mk=='|' else 18,alpha=1 if row['input_relevant'] else .3)
        if ai==0:
            if abs(row['level_or_ray']-40.81)<.001:bx.annotate(f'{row["id"]} · f{row["foot"]}\n{row["degrees"]:.3f}°',(row['degrees'],y0),xytext=(0,24 if row['foot']==1 else -38),textcoords='offset points',ha='center',fontsize=8,color=color,arrowprops={'arrowstyle':'-','color':color,'lw':.6})
    bx.axvline(lim,color='#d63345',lw=1.4,ls='--');bx.axvspan(0,lim,color='#dbeafe',alpha=.45);bx.set(xlim=(lo,hi),ylim=(-.65,5.8),yticks=list(range(6)),yticklabels=['r0','r1','a0','a1','rim','corner'],xlabel='Clockwise stop angle s (degrees)',title=title);bx.grid(axis='x',alpha=.13)
    if ai==0:bx.text(.02,.97,'f1 enters a0: 3.692660°\nf2 reaches a0: 63.692660°\nLast accepted 1/3° step: 63.666667°',transform=bx.transAxes,va='top',fontsize=9,linespacing=1.6)
    else:bx.text(.02,.97,'Blue: f1 · Purple: f2\n40 event angles; all listed in the report.\nNo rim or span-ray intersections for this arm.',transform=bx.transAxes,va='top',fontsize=9,linespacing=1.5)
fig.suptitle('The swing is circle geometry; the legal stop also needs the rule state',fontsize=18,fontweight='bold')
save(fig,'04-swing-geometry')

# Different geometry at l580: start rim and the nearby span SUPPORT LINE.
seed=np.array(DATA['poses'][2]['p'][3:]);fig,axs=plt.subplots(1,3,figsize=(13.5,4.8),layout='constrained')
rimdata=json.loads((BASE/'rim-data.json').read_text())
for ax,t,rg in zip(axs,[-1.5,0,1.5],rimdata['grids']):
    ex=extras(np.linspace(-1.5,1.5,241),seed,t)
    for z in ex:
        if z['family'] not in ['A4','A5']:continue
        for a in z['segments']:ax.plot(a[:,0],a[:,1],color=COL[z['family']],lw=1.6)
    xx,yy=np.meshgrid(np.linspace(-1.5,1.5,241),np.linspace(-1.5,1.5,241));fx,fy=feet(seed[0]+xx,seed[1]+yy,seed[2]+t/R);A=RAYS[3][0]
    # Show the support ray without claiming it is a contact boundary when the radial band is absent.
    z=(fx[1]-66.667)*np.sin(A)-fy[1]*np.cos(A)
    for a in contours(np.linspace(-1.5,1.5,241),np.linspace(-1.5,1.5,241),z):ax.plot(a[:,0],a[:,1],color='#e0a12b',lw=1.2,ls=':')
    bad=np.any(np.hypot(fx,fy)>67.167,axis=0);ax.contourf(np.linspace(-1.5,1.5,241),np.linspace(-1.5,1.5,241),bad,levels=[.5,1.5],colors=['#d63345'],alpha=.1)
    xx2,yy2=np.meshgrid(np.linspace(-1.5,1.5,rg['n']),np.linspace(-1.5,1.5,rg['n']));fx2,fy2=feet(seed[0]+xx2,seed[1]+yy2,seed[2]+t/R);legal=np.all(np.hypot(fx2,fy2)<=67.167,axis=0)
    for k,a in enumerate(DATA['arms']):
        lims=np.array([[pt[k]['lim'] for pt in row] for row in rg['rows']]);lims=np.where(legal,lims,np.nan)
        for seg in contours(np.linspace(-1.5,1.5,rg['n']),np.linspace(-1.5,1.5,rg['n']),lims-2):ax.plot(seg[:,0],seg[:,1],color=COL['A3'],lw=.85,alpha=.65)
    boxes(ax);ax.set_title(f'l5807vazg · t = {t:+g}u')
fig.suptitle('Near the rim: legal starting poses are clipped before any throw analysis',fontsize=16,fontweight='bold')
fig.supxlabel('Red/pink: starting rim / already off board. Purple: sampled 2° legality transitions. Green: start state. Gold: span support, not a contact boundary by itself.',fontsize=9)
save(fig,'05-rim-slices')
print('Root residual max',max(r['residual_u'] for r in rows),'u')
print('Extra walls',json.dumps(summary,indent=2))
print('Plots saved',OUT)
