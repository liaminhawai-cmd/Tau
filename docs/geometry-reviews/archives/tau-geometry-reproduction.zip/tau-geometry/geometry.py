"""Analytic event geometry for the pinned PR18 constants. No push simulation."""
from pathlib import Path
import json, math
import numpy as np
import contourpy
BASE=Path(__file__).resolve().parent
DATA=json.loads((BASE/'geometry-data.json').read_text())
R=DATA['CFG']['footR']; RHO=R*np.sqrt(3); TAU=2*np.pi; RAD=np.pi/180
SEED=np.array(DATA['poses'][0]['p'][:3]); OFF=np.arange(3)*TAU/3
CENTRES=np.array([[0,0],[0,0],[-66.667,0],[66.667,0],[0,0]]+[[c['x'],c['y']] for c in DATA['corners']])
LEVELS=[[39.19,40,40.81],[52.49,53.3,54.11],[39.19,40,40.81],[39.19,40,40.81],[67.167]]+[[.81]]*8
NAMES=['r0','r1','a0','a1','rim']+['c'+str(k) for k in range(8)]
RAYS={2:np.array([-72.542,72.542])*RAD,3:np.array([107.458,252.542])*RAD}
def feet(x,y,theta):
    return np.array([np.asarray(x)+R*np.cos(theta+a) for a in OFF]),np.array([np.asarray(y)+R*np.sin(theta+a) for a in OFF])
def delta(i,p):return np.angle(np.exp(1j*OFF[i])-np.exp(1j*OFF[p]))
def descriptors(p):
    out=[]
    for i in range(3):
        if i==p:continue
        for ci,levels in enumerate(LEVELS):
            for D in levels:
                for sign in [1,-1]:out.append(dict(foot=i,circle=ci,kind='level',D=D,sign=sign))
            for A in RAYS.get(ci,[]):
                for sign in [1,-1]:out.append(dict(foot=i,circle=ci,kind='ray',A=float(A),sign=sign))
    return out
def phase(e,px,py,p):
    ux=px-CENTRES[e['circle'],0];uy=py-CENTRES[e['circle'],1]
    d=np.hypot(ux,uy)
    with np.errstate(divide='ignore',invalid='ignore'):
        if e['kind']=='level':
            c=(e['D']**2-d*d-RHO*RHO)/(2*RHO*d)
            beta=np.arctan2(uy,ux)+e['sign']*np.arccos(np.clip(c,-1,1));ok=(abs(c)<1)&(d>1e-12)
        else:
            A=e['A'];v=-(ux*np.sin(A)-uy*np.cos(A))/RHO
            b=np.arcsin(np.clip(v,-1,1));beta=A-(b if e['sign']>0 else np.pi-b);ok=abs(v)<1
    return np.where(ok,beta-delta(e['foot'],p),np.nan)
def angle(e,x,y,theta,p,dir):
    px=x+R*np.cos(theta+OFF[p]);py=y+R*np.sin(theta+OFF[p]);return np.mod(dir*(phase(e,px,py,p)-theta),TAU)
def physical(e,px,py,p):
    """Whether this geometric root can change a rule input (span/ray gating)."""
    b=phase(e,px,py,p)+delta(e['foot'],p);fx=px+RHO*np.cos(b);fy=py+RHO*np.sin(b)
    ci=e['circle'];ux=fx-CENTRES[ci,0];uy=fy-CENTRES[ci,1]
    if ci in (2,3):
        if e['kind']=='ray':
            return (ux*np.cos(e['A'])+uy*np.sin(e['A'])>=-1e-9)&(abs(np.hypot(ux,uy)-40)<.8100001)
        bearing=np.mod(np.arctan2(uy,ux)-RAYS[ci][0],TAU)
        return bearing <= RAYS[ci][1]-RAYS[ci][0]+1e-8
    return np.isfinite(b)
def label(e):
    q=f"f{e['foot']}:{NAMES[e['circle']]}"
    q+= f"/{e['D']:g}" if e['kind']=='level' else f"/ray{e['A']/RAD:.3f}"
    return q+('(+)' if e['sign']>0 else '(-)')
def contours(x,y,z):
    if not np.isfinite(z).any():return []
    if np.nanmin(z)>0 or np.nanmax(z)<0:return []
    return [a for a in contourpy.contour_generator(x=x,y=y,z=np.ma.masked_invalid(z),corner_mask=False).lines(0) if len(a)>1]
def line_segments_with_mask(seg,maskfun):
    ok=np.asarray(maskfun(seg[:,0],seg[:,1]),dtype=bool)
    if ok.ndim==0:return [seg] if ok else []
    changes=np.flatnonzero(np.diff(np.r_[False,ok,False]));return [seg[a:b] for a,b in changes.reshape(-1,2) if b-a>=2]
def generate_catalog(res=161):
    """All distinct pre-stop, input-relevant A1 coincidences visible in the five requested slices.
    Geometric candidates only: equality is not by itself a change in the stopping program.
    A1 roots are analytic functions sampled solely for contour rendering.
    """
    ax=np.linspace(-1.5,1.5,res);xx,yy=np.meshgrid(ax,ax);catalog={};slices=[]
    for gi,g in enumerate(DATA['grids']):
        th=SEED[2]+g['t']/R;x=SEED[0]+xx;y=SEED[1]+yy;walls=[]
        # Conservative upper range of the actual limit in this slice; trim at the
        # local sampled limit + two substeps, avoiding irrelevant events after stopping.
        n=g['n']; idx=np.clip(np.rint((xx+1.5)/3*(n-1)).astype(int),0,n-1);idy=np.clip(np.rint((yy+1.5)/3*(n-1)).astype(int),0,n-1)
        lims=np.array([[[q[k]['lim'] for k in range(6)] for q in row] for row in g['rows']])*RAD
        for p in range(3):
            px=x+R*np.cos(th+OFF[p]);py=y+R*np.sin(th+OFF[p]);es=descriptors(p)
            gs=[phase(e,px,py,p) for e in es];oks=[physical(e,px,py,p) for e in es]
            for ei,e in enumerate(es):
                if not np.isfinite(gs[ei]).any():continue
                for ej in range(ei+1,len(es)):
                    f=es[ej]
                    if e['circle']==f['circle'] and e['kind']==f['kind']:continue
                    if not np.isfinite(gs[ej]).any():continue
                    diff=np.angle(np.exp(1j*(gs[ei]-gs[ej])))
                    mask=(abs(diff)<.12)&oks[ei]&oks[ej]
                    if not mask.any():continue
                    for dr,ki in [(1,2*p),(-1,2*p+1)]:
                        ss=np.mod(dr*(gs[ei]-th),TAU);ff=np.mod(dr*(gs[ej]-th),TAU)
                        keep=mask&(abs(ss-ff)<.12)&(ss<lims[idy,idx,ki]+2*RAD/3)&(ss>0)
                        z=np.where(keep,diff,np.nan);segs=contours(ax,ax,z)
                        if not segs:continue
                        key=f'{p},{dr}|{label(e)}={label(f)}'
                        if key not in catalog:catalog[key]={'id':f'E{len(catalog)+1:02d}','p':p,'dir':dr,'e':e,'f':f,'family':'A1','description':f'({p},{"+" if dr>0 else "−"}) {label(e)} = {label(f)}'}
                        walls.append({'key':key,'segments':[a.tolist() for a in segs]})
        slices.append({'t':g['t'],'walls':walls})
        print('catalog slice',g['t'],len(walls),flush=True)
    out={'catalog':catalog,'slices':slices,'resolution':res,'scope':'All input-relevant pre-stop A1 candidates resolved in five requested slices; no volumetric completeness proof.'}
    (BASE/'wall-catalog.json').write_text(json.dumps(out));return out
if __name__=='__main__':
    cat=generate_catalog()
    for v in cat['catalog'].values():print(v['id'],v['description'])
