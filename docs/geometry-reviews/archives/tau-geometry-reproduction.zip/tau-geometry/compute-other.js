const fs=require('fs'),F=require('./source/forced-win.js'),C=require('./source/contact-law.js');
const data=JSON.parse(fs.readFileSync(__dirname+'/geometry-data.json')),seed=data.poses[2],n=65;
const out={id:seed.id,grids:[],events:{}};const ek=e=>[e.foot,e.circle,e.kind,e.D??e.A,e.sign].join(':');
for(const t of [-1.5,0,1.5]){
 const g={t,n,rows:[]};
 for(let j=0;j<n;j++){const row=[];for(let i=0;i<n;i++){
 const ps=F.piecesOf(seed.p);ps[1].x+=-1.5+3*i/(n-1);ps[1].y+=-1.5+3*j/(n-1);ps[1].rot+=t/C.R;
 row.push(data.arms.map(a=>{const l=F.limitAt(ps,1,a.p,a.dir);for(const e of l.events||[])out.events[ek(e)]=e;return {lim:l.lim*180/Math.PI,sig:l.sig,events:(l.events||[]).map(ek)}}));
 }g.rows.push(row);}
 out.grids.push(g);console.log('l580',t);
}
out.axisChecks=[];
for(const [axis,d] of [[0,1.25],[2,-1.5]]){const ps=F.piecesOf(seed.p);ps[1][['x','y','rot'][axis]]+=axis===2?d/C.R:d;out.axisChecks.push({axis,d,radii:C.feetOf(ps[1]).map(f=>Math.hypot(f.x,f.y)),limits:data.arms.map(a=>F.limitAt(ps,1,a.p,a.dir).lim*180/Math.PI)});}
fs.writeFileSync(__dirname+'/rim-data.json',JSON.stringify(out));console.log(out.axisChecks);
