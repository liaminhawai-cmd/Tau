const fs=require('fs');
const F=require('./source/forced-win.js'), C=require('./source/contact-law.js');
const poses=[
{id:'ndpxhts24',victim:0,p:[-27.3934,-36.4088,1.2052,-11.7593,-23.2838,2.9442]},
{id:'6dgqa1fd8',victim:1,p:[2.6627,33.2224,2.2687,4.2061,47.1181,4.4905]},
{id:'l5807vazg',victim:1,p:[37.6039,-3.2612,1.8896,50.4287,10.5092,-.859]},
{id:'0r8c3cohc',victim:1,p:[.8192,-30.3367,-3.2227,19.4916,-35.329,4.106]}
];
const arms=Array.from({length:3},(_,p)=>[1,-1].map(dir=>({p,dir}))).flat();
const ek=e=>[e.foot,e.circle,e.kind,e.D??e.A,e.sign].join(':');
const events={};
function compact(pieces,victim){return arms.map(a=>{const l=F.limitAt(pieces,victim,a.p,a.dir);for(const e of l.events||[])events[ek(e)]={...e};return {lim:l.lim*180/Math.PI,sig:l.sig,events:(l.events||[]).map(ek)};});}
const out={commit:'e32f09d5be9600212c3d5294b70a3835f0517427',CFG:C.eng.CFG,corners:C.eng.LINE_INTERSECTIONS,arms,poses:poses.map(q=>({...q,feet:F.piecesOf(q.p).map(C.feetOf),limits:compact(F.piecesOf(q.p),q.victim)})),grids:[],events};
const n=65;
for(const t of [-1.5,-.75,0,.75,1.5]){
 const grid={t,n,lo:-1.5,hi:1.5,rows:[]};
 for(let j=0;j<n;j++){const row=[];for(let i=0;i<n;i++){
  const p=F.piecesOf(poses[0].p);p[0].x+=-1.5+3*i/(n-1);p[0].y+=-1.5+3*j/(n-1);p[0].rot+=t/C.R;
  row.push(compact(p,0));
 }grid.rows.push(row);}
 out.grids.push(grid);console.log('slice',t,'done');
}
const q=F.piecesOf(poses[0].p);out.swingEvents=F.limitEvents(C.feetOf(q[0]),0,-1);
const crossChecks=[];
for(const seed of poses){const ps=F.piecesOf(seed.p);for(const a of arms){const exact=F.limitAt(ps,seed.victim,a.p,a.dir),step=F.limitLadder(ps,seed.victim,a.p,a.dir);crossChecks.push({id:seed.id,...a,error:Math.abs(exact.lim-step.lim),signatureMatch:exact.sig===step.sig});}}
out.crossChecks=crossChecks;
fs.writeFileSync(__dirname+'/geometry-data.json',JSON.stringify(out));
for(let k=0;k<6;k++){
const tally={};for(const grid of out.grids)for(const row of grid.rows)for(const pt of row){const l=pt[k];const key=l.sig+'|'+l.events.join(',');tally[key]=(tally[key]||0)+1;}
console.log(arms[k],tally);
}
console.log('checks',Math.max(...crossChecks.map(x=>x.error)),crossChecks.every(x=>x.signatureMatch));
