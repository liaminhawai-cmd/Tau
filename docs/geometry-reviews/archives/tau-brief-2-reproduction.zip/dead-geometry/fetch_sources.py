"""Retrieve the exact public Tau revision used for engine comparisons."""
from pathlib import Path
from urllib.request import urlopen
BASE=Path(__file__).resolve().parent
SHA='e32f09d5be9600212c3d5294b70a3835f0517427'
for name in ['index.html','nn/forced-win.js','nn/contact-law.js','nn/engine.js','nn/opening.js']:
    dest=BASE/('index.html' if name=='index.html' else 'source/'+name.split('/')[-1]);dest.parent.mkdir(parents=True,exist_ok=True)
    url=f'https://raw.githubusercontent.com/liaminhawai-cmd/Tau/{SHA}/{name}'
    with urlopen(url) as r:dest.write_bytes(r.read())
    print('Retrieved',name)
