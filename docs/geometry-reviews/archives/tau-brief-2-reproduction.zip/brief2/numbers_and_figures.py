from pathlib import Path
import json, math
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

B=Path(__file__).resolve().parent
(B/'figures').mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none'})
R=23.095; d=2.88; ht=math.pi/3600; P=math.hypot(.01,.01)+R*ht
c=math.cos(math.radians(73)); sigma=math.sin(math.radians(73)); kappa=d/R
den=1-kappa/(1-c); CA=(1/sigma+kappa/sigma**2)/den
bs_line=P/sigma+d*ht/sigma**2; bs_smooth=bs_line/den
rows=[]
for kind,bs,epsilon in [('Smooth isolated interior',bs_smooth,(2*bs_smooth/R+ht)/sigma),('One segment pair, clamping allowed',bs_line,P/(d-P)+ht/sigma),('One segment pair, both interior',bs_line,ht/sigma)]:
    beta=epsilon/(.63-epsilon); hlo=.63-epsilon
    width=lambda L,eps:.0+eps/(hlo*math.cos(beta))+2*math.sqrt(2)*.01*math.tan(beta)+2*ht*L/math.cos(beta)
    rows.append(dict(kind=kind,param_half=bs,param_width=2*bs,world_victim_radius=P+bs,world_victim_diameter=2*(P+bs),normal_error=epsilon,cone_half_deg=beta*180/math.pi,hf_lo=hlo,width_LR=width(R,.005),width_L85=width(8.5,.005),width_L85_shell001=width(8.5,.001)))
I=.7*R*R; alpha=R/math.sqrt(I); pcoef=math.sqrt(1+alpha*alpha)
bscoef=pcoef/sigma+d/(math.sqrt(I)*sigma*sigma)
Ms=[]
for kind,kn in [('interior',1/(math.sqrt(I)*sigma)),('clamping allowed',pcoef/(d-P)+1/(math.sqrt(I)*sigma))]:
    M=math.hypot(kn,alpha*kn+alpha/math.sqrt(I)+bscoef/math.sqrt(I))
    Ms.append(dict(kind=kind,M=M,normal_derivative_at_p06=M*.06/.60**2,shell_residual_at_p06=M*.06**2/(2*.60**2)))
checks=json.loads((B/'checks.json').read_text()); u=checks['updates']; before=abs(u[0]['first']['c']['dist']-u[1]['first']['c']['dist']);after=abs(u[0]['finalGap']-u[1]['finalGap'])
result=dict(R=R,I=I,P=P,pad=math.hypot(.01,.01)+2*R*math.sin(ht/2),CA=CA,rows=rows,hessian=Ms,gapBeforeDifference=before,gapAfterDifference=after,gapRatio=after/before)
(B/'numeric-bounds.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))

def save(fig,name):
    fig.savefig(B/'figures'/f'{name}.svg',bbox_inches='tight');fig.savefig(B/'figures'/f'{name}.png',dpi=160,bbox_inches='tight');plt.close(fig)

tie=checks['tie']; colors=['#2765ad','#b34839']
fig=plt.figure(figsize=(12,4.9));ax=fig.add_subplot(121,projection='3d')
for pose,color,label,inds in [(tie['attacker'],colors[0],'Attacker leg 0',range(2,5)),(tie['victim'],colors[1],'Victim leg 0',range(4,6))]:
    phi=np.array(list(inds))*math.pi/24
    x=pose['x']+R*np.sin(phi)*math.cos(pose['rot']);y=pose['y']+R*np.sin(phi)*math.sin(pose['rot']);z=R*np.cos(phi)
    ax.plot(x,y,z,'o-',color=color,label=label,lw=2,ms=4)
for pair,sty in [(tie['pair1'],'-'),(tie['pair2'],'--')]:
    a,v=pair['pa'],pair['pb'];ax.plot([a['x'],v['x']],[a['y'],v['y']],[a['h'],v['h']],sty,color='#2d3640',lw=2)
ax.set(xlabel='x (u)',ylabel='y (u)',zlabel='height (u)',title='Two interior minima at one pose')
ax.view_init(22,-66);ax.legend(loc='upper left',fontsize=8)
ax=fig.add_subplot(122)
for pair,xspan in [(tie['pair1'],[-1e-4,0]),(tie['pair2'],[0,1e-4])]:
    bearing=math.degrees(math.atan2(pair['n'][1],pair['n'][0]));ax.plot(np.array(xspan)*1e6,[bearing,bearing],color='#2765ad',lw=3)
ax.axvline(0,color='#98a5b4',ls=':');ax.set(xlabel='Victim x offset from tie (millionths of u)',ylabel='Horizontal normal bearing (degrees)',title='The normal has a finite jump')
ax.text(.06,.10,f"Unit-normal jump: {tie['normalJump']:.6f}\nBoth gaps: {tie['pair1']['d']:.6f} u < 2.88 u",transform=ax.transAxes,bbox=dict(facecolor='#edf2f7',edgecolor='none',pad=10))
fig.subplots_adjust(wspace=.27);save(fig,'01-contact-switch')

ph=json.loads((B/'phase-check.json').read_text());fig,axes=plt.subplots(1,2,figsize=(12,4.1))
for ax,spin,title in [(axes[0],ph['spins'][1],'6dgqa1fd8 · pivot 0 fixed'),(axes[1],ph['spins'][0],'0r8c3cohc · pivot 2 fixed')]:
    ax.step([r['dthetaDeg'] for r in spin['rows']],[r['lim'] for r in spin['rows']],where='mid',color='#2765ad',lw=2)
    ax.set(xlabel='Rotation offset with pivot held fixed (degrees)',ylabel='Accepted arm limit (degrees)',title=title);ax.grid(alpha=.2)
fig.suptitle('The sampling phase can change the stopping program',fontweight='bold',y=1.04);fig.tight_layout();save(fig,'02-phase-limits')

wd=json.loads((B/'walls-data.json').read_text());C0=wd['exactChecks']['C']['foot'];p0=np.array([C0['x'],C0['y']]); K8=np.array([wd['corners'][7]['x'],wd['corners'][7]['y']]);rho=math.sqrt(3)*R
fig,ax=plt.subplots(figsize=(8,6))
theta=np.linspace(0,2*math.pi,3000)
for center,r,label,col in [(np.zeros(2),53.3,'C: start-side circle','#2765ad'),(np.array([66.667,0]),rho+40.81,'D: band tangency','#ad6c22'),(K8,rho+.81,'E: corner tangency candidate','#8f5699')]:
    ax.plot(center[0]+r*np.cos(theta),center[1]+r*np.sin(theta),label=label,color=col,lw=2)
for t in np.linspace(-1,1,9):
    ang=4.106+t/R; f=np.array([19.4916,-35.329])+R*np.array([math.cos(ang),math.sin(ang)])
    rect=np.array([[-1,-1],[1,-1],[1,1],[-1,1],[-1,-1]])+f;ax.plot(rect[:,0],rect[:,1],color='#aab5c1',alpha=.35,lw=.8)
ax.scatter(*p0,color='#202c3d',zorder=5);ax.annotate('Seed foot 0 = pivot 0',p0,xytext=(4.0,-55.9),arrowprops=dict(arrowstyle='-',color='#657386'))
e=json.loads((B/'e-candidates.json').read_text())[0];ang=e['pose']['rot'];pf=np.array([e['pose']['x'],e['pose']['y']])+R*np.array([math.cos(ang),math.sin(ang)])
ax.scatter(*pf,color='#b34839',marker='x',s=65,zorder=5,label='Long a1/r1 program; no corner-disc contact')
ax.set(xlim=(3.7,9.4),ylim=(-56.1,-52.1),xlabel='Foot-0 / pivot-0 x (u)',ylabel='Foot-0 / pivot-0 y (u)',title='C, D and E share the same physical foot plane')
ax.set_aspect('equal');ax.grid(alpha=.2);ax.legend(loc='upper left',fontsize=8)
save(fig,'03-shared-foot-plane')
