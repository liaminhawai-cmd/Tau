const fs=require('fs'),F=require('../dead-geometry/source/forced-win.js'),C=require('../dead-geometry/source/contact-law.js');
const R=C.R,deg=Math.PI/180;
const seeds={six:[2.6627,33.2224,2.2687,4.2061,47.1181,4.4905],zero:[.8192,-30.3367,-3.2227,19.4916,-35.329,4.106]};
function ps(name,o){const a=seeds[name].slice();a[3]+=o[0];a[4]+=o[1];a[5]+=o[2]/R;return F.piecesOf(a);}
function at(name,o,pv=0){const a=ps(name,o),l=F.limitAt(a,1,pv,1),P=C.feetOf(a[1])[pv],K=C.eng.LINE_INTERSECTIONS[name==='six'?5:7];return{o,lim:l.lim/deg,crossed:l.crossed,P,pivotK:Math.hypot(P.x-K.x,P.y-K.y),events:l.events};}
const path=[];for(let j=0;j<=200;j++)path.push(at('six',[-j/200,0,-j/200]));
console.log('six path switches',path.filter((r,i)=>i===0||JSON.stringify(r.crossed)!==JSON.stringify(path[i-1].crossed)).map(r=>({o:r.o,lim:r.lim,crossed:r.crossed,pivotK:r.pivotK})));
function spin(name,o,pv){const a=ps(name,o),base=a[1],P=C.feetOf(base)[pv],rows=[];
 for(let j=0;j<=120;j++){const dth=(j-60)/120*deg/3,q={...base,rot:base.rot+dth};q.x=P.x-R*Math.cos(q.rot+pv*2*Math.PI/3);q.y=P.y-R*Math.sin(q.rot+pv*2*Math.PI/3);a[1]=q;const l=F.limitAt(a,1,pv,1);rows.push({dthetaDeg:dth/deg,pose:q,lim:l.lim/deg,crossed:l.crossed});}
 console.log('spin',name,pv,o,rows.filter((r,i)=>i===0||JSON.stringify(r.crossed)!==JSON.stringify(rows[i-1].crossed)).map(r=>({dthetaDeg:r.dthetaDeg,pose:r.pose,lim:r.lim,crossed:r.crossed})));return{ name,pv,o,P,rows};}
const spins=[spin('zero',[-.9,.8,.9],2)];
for(const a of [.65,.7,.75,.8,.85,.9,.95,1])spins.push(spin('six',[-a,0,-a],0));
fs.writeFileSync(__dirname+'/phase-check.json',JSON.stringify({path,spins},null,2));
