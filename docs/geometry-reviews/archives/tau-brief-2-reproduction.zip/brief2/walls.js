// Read-only investigation against the engine pinned by Brief 2.
const fs=require('fs');
const F=require('../dead-geometry/source/forced-win.js');
const C=require('../dead-geometry/source/contact-law.js');
const R=C.R,rho=Math.sqrt(3)*R,deg=Math.PI/180,E=C.eng;
const seeds={six:[2.6627,33.2224,2.2687,4.2061,47.1181,4.4905],zero:[.8192,-30.3367,-3.2227,19.4916,-35.329,4.106],ell:[37.6039,-3.2612,1.8896,50.4287,10.5092,-.859]};
function pose(name,offset=[0,0,0]){const p=seeds[name].slice();p[3]+=offset[0];p[4]+=offset[1];p[5]+=offset[2]/R;return F.piecesOf(p);}
function circleData(p,j,c,r){const f=C.feetOf(p)[j],dx=f.x-c[0],dy=f.y-c[1],d=Math.hypot(dx,dy),th=p.rot+j*2*Math.PI/3,n=[dx/d,dy/d];const g=[...n,-n[0]*Math.sin(th)+n[1]*Math.cos(th)],len=Math.hypot(...g);return{foot:f,d,r,value:d-r,gradient:g,normal:g.map(v=>v/len),linearDistance:(d-r)/len};}
function inspect(name,pv,dr,offset=[0,0,0]){const ps=pose(name,offset),p0={...ps[1]},g={contact:null,pinned:pv,crossings:0,justCrossed:[]},rows=[];let before=C.feetOf(p0),last='';
for(let k=1;k<400;k++){const p=F.moverAt(p0,pv,dr,k*deg/3),after=C.feetOf(p),stBefore=JSON.parse(JSON.stringify(g));const stop=E.crossingSubstep(before,after,g),near=after.map(f=>E.nearLineIds(f,.81));const sig=JSON.stringify([near,g.crossings,g.justCrossed,stop]);if(sig!==last){rows.push({k,deg:k/3,near,stop,feet:after,stateBefore:stBefore,state:JSON.parse(JSON.stringify(g))});last=sig;}if(stop||C.anyOff(p))break;before=after;}
return{offset,limit:F.limitAt(ps,1,pv,dr),rows};}
const K6=[-42.64,31.98],K8=[42.64,-31.98]; // use engine's exact intersections below
const corners=E.LINE_INTERSECTIONS;console.log('corners',corners);
const k6=corners.find(p=>p.x<-40&&p.y>0),k8=corners.find(p=>p.x>40&&p.y<0);
const out={R,rho,corners,seeds,exactChecks:{},traces:[]};
const cp=p=>[p.x,p.y];
out.exactChecks.six=circleData(pose('six')[1],0,cp(k6),rho+.81);
out.exactChecks.C=circleData(pose('zero')[1],0,[0,0],53.3);
out.exactChecks.D=circleData(pose('zero')[1],0,[66.667,0],rho+40.81);
out.exactChecks.E=circleData(pose('zero')[1],0,cp(k8),rho+.81);
out.exactChecks.A=circleData(pose('ell')[1],2,[66.667,0],40);
for(const [name,pv,dr,offset] of [['six',0,1,[0,0,0]],['six',0,1,[-1,0,-1]],['zero',0,1,[0,0,0]],['zero',0,1,[1,1,1]],['zero',2,1,[0,0,0]],['zero',2,1,[-.9,.8,.9]]])out.traces.push({name,pv,dr,...inspect(name,pv,dr,offset)});
fs.writeFileSync(__dirname+'/walls-data.json',JSON.stringify(out,null,2));console.log(JSON.stringify(out.exactChecks,null,2));
const eCases=[];for(let i=0;i<=10;i++)for(let j=0;j<=10;j++)for(let k=0;k<=10;k++){const o=[-1+.2*i,-1+.2*j,-1+.2*k],a=pose('zero',o),l=F.limitAt(a,1,0,1);if(l.crossed.includes('a1')&&l.crossed.includes('r1')){const P=C.feetOf(a[1])[0],d=Math.hypot(P.x-k8.x,P.y-k8.y);eCases.push({o,pose:a[1],lim:l.lim/deg,d});}}
eCases.sort((a,b)=>b.d-a.d);fs.writeFileSync(__dirname+'/e-candidates.json',JSON.stringify(eCases,null,2));console.log('E diagnostic cases',eCases.length);
