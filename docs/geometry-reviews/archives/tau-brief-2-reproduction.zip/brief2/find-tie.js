const fs=require('fs'),path=require('path'),Module=require('module');
const srcfile=path.resolve(__dirname,'../dead-geometry/source/contact-law.js');
const m=new Module(srcfile);m.filename=srcfile;m.paths=Module._nodeModulePaths(path.dirname(srcfile));
let src=fs.readFileSync(srcfile,'utf8').replace('if (require.main !== module) return;','module.exports.geom={arcsOf,segClosest3,arcClosest,rotateAround}; if (require.main !== module) return;');m._compile(src,srcfile);
const C=m.exports,F=require('../dead-geometry/source/forced-win.js');
const seed=F.piecesOf([-27.3934,-36.4088,1.2052,-11.7593,-23.2838,2.9442]);
seed[0]=F.moverAt(seed[0],0,1,8*Math.PI/180);
const swing=C.swing(seed,1,0,-1,46*Math.PI/180,{...C.REPLICA,trace:true,record:true});
function pairs(a,v){const aa=C.geom.arcsOf(a,12)[0],vv=C.geom.arcsOf(v,12)[0],rows=[];
 for(let i=0;i<12;i++)for(let j=0;j<12;j++){
 const c=C.geom.segClosest3(aa[i],aa[i+1],vv[j],vv[j+1]);
 const vec=(u,v)=>[v.x-u.x,v.y-u.y,v.h-u.h];const norm=v=>Math.hypot(...v),unit=v=>v.map(x=>x/norm(v)),dot=(u,v)=>u.reduce((s,x,k)=>s+x*v[k],0);
 const a1=vec(aa[i],aa[i+1]),v1=vec(vv[j],vv[j+1]),n=unit(vec(c.pa,c.pb));
 const sa=dot(vec(aa[i],c.pa),a1)/dot(a1,a1),sv=dot(vec(vv[j],c.pb),v1)/dot(v1,v1);
 rows.push({i,j,d:c.dist,pa:c.pa,pb:c.pb,n,sa,sv,chi:Math.acos(dot(unit(a1),unit(v1)))*180/Math.PI});
 }return rows.sort((a,b)=>a.d-b.d);
}
const out={seed,offAt:swing.offAt,margin:swing.maxFootR-C.EDGE,records:swing.record,trace:swing.trace,features:[]};
let prior='';for(let k=1;k<=70;k++){
 const a=F.moverAt(seed[1],0,-1,k*.4*Math.PI/180),v=k===1?seed[0]:swing.record[k-2];const pp=pairs(a,v);
 out.features.push({k,attacker:a,victim:v,pairs:pp.slice(0,8)});const tag=pp[0].i+','+pp[0].j;
 if(tag!==prior){console.log('switch',k,tag,'chi',pp[0].chi,'dist',pp[0].d,'next',pp[1].i,pp[1].j,pp[1].d);prior=tag;}
}
// Search a tie between competing interiors near the observed feature change,
// holding the attacker fixed and translating only the victim horizontally.
const ties=[];
for(const row of out.features){if(row.k<12)continue;
 const base=row.victim,a=row.attacker;
 for(const axis of ['x','y']){
  let prev=null;
  for(let z=-.5;z<=.5000001;z+=.01){const v={...base,[axis]:base[axis]+z},pp=pairs(a,v),top=pp[0];
   if(prev&&(prev.top.i!==top.i||prev.top.j!==top.j)){
    const id1=[prev.top.i,prev.top.j],id2=[top.i,top.j];
    const evalAt=t=>{const q={...base,[axis]:base[axis]+t},ps=pairs(a,q);return{q,ps,p1:ps.find(x=>x.i===id1[0]&&x.j===id1[1]),p2:ps.find(x=>x.i===id2[0]&&x.j===id2[1])}};
    let lo=prev.z,hi=z;for(let it=0;it<45;it++){const mid=(lo+hi)/2,e=evalAt(mid);if(e.p1.d-e.p2.d<0)lo=mid;else hi=mid;}
    const t=(lo+hi)/2,e=evalAt(t),dist=(x,y)=>Math.hypot(x.x-y.x,x.y-y.y,x.h-y.h);
    if(e.p1.d<2.88 && dist(e.p1.pa,e.p2.pa)>.01&&e.p1.sa>1e-6&&e.p1.sa<1-1e-6&&e.p2.sa>1e-6&&e.p2.sa<1-1e-6&&e.p1.sv>1e-6&&e.p1.sv<1-1e-6&&e.p2.sv>1e-6&&e.p2.sv<1-1e-6){
     const nJump=Math.hypot(...e.p1.n.map((x,j)=>x-e.p2.n[j]));ties.push({k:row.k,axis,offset:t,attacker:a,victim:e.q,pair1:e.p1,pair2:e.p2,attackerPointJump:dist(e.p1.pa,e.p2.pa),victimPointJump:dist(e.p1.pb,e.p2.pb),normalJump:nJump,nearMinus:evalAt(t-1e-7).ps[0],nearPlus:evalAt(t+1e-7).ps[0]});
     console.log('TIE',JSON.stringify(ties[ties.length-1]));break;
    }
   }prev={z,top};
  }if(ties.length)break;
 }if(ties.length)break;
}
out.ties=ties;fs.writeFileSync(__dirname+'/contact-tie.json',JSON.stringify(out,null,2));
console.log('result',{margin:out.margin,offDeg:out.offAt*180/Math.PI,ties:ties.length});
