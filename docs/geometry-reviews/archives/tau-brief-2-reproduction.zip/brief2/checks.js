const fs=require('fs'),path=require('path'),Module=require('module');
const file=path.resolve(__dirname,'../dead-geometry/source/contact-law.js'),m=new Module(file);m.filename=file;m.paths=Module._nodeModulePaths(path.dirname(file));
m._compile(fs.readFileSync(file,'utf8').replace('if (require.main !== module) return;','module.exports.geom={arcsOf,segClosest3,arcClosest}; if (require.main !== module) return;'),file);
const C=m.exports,F=require('../dead-geometry/source/forced-win.js'),R=C.R,I=C.I,D=2.88;
const tie=JSON.parse(fs.readFileSync(__dirname+'/contact-tie.json')).ties[0];
const out={tie,contacts:[],updates:[],phaseChecks:[]};
function closest(a,v,i=0,j=0){return C.geom.arcClosest(C.geom.arcsOf(a,12)[i],C.geom.arcsOf(v,12)[j]);}
function update(a,q){const p={...q},c=closest(a,p),dx=c.pb.x-c.pa.x,dy=c.pb.y-c.pa.y,h=Math.hypot(dx,dy)/c.dist,n=[dx/(c.dist*h),dy/(c.dist*h)],rn=(c.pb.x-p.x)*n[1]-(c.pb.y-p.y)*n[0],s=(D-c.dist)/h,lambda=s/(1+rn*rn/I);if(s>0){p.x+=lambda*n[0];p.y+=lambda*n[1];p.rot+=lambda*rn/I;}return{p,c,h,n,rn,s,lambda};}
for(let i=0;i<3;i++)for(let j=0;j<3;j++)out.contacts.push({i,j,d:closest(tie.attacker,tie.victim,i,j).dist});
for(const off of [-1e-7,1e-7]){let p={...tie.victim,x:tie.victim.x+off},first;for(let k=0;k<10;k++){const u=update(tie.attacker,p);if(k===0)first=u;if(u.s<=0)break;p=u.p;}out.updates.push({off,first,final:p,finalGap:closest(tie.attacker,p).dist-D});}
out.updateJump={one:Math.hypot(out.updates[0].first.p.x-out.updates[1].first.p.x,out.updates[0].first.p.y-out.updates[1].first.p.y),ten:Math.hypot(out.updates[0].final.x-out.updates[1].final.x,out.updates[0].final.y-out.updates[1].final.y),tenRot:out.updates[0].final.rot-out.updates[1].final.rot};
// Expose resolvePush in memory only; run the game's actual full contact loop.
const ef=path.resolve(__dirname,'../dead-geometry/source/engine.js'),em=new Module(ef);em.filename=ef;em.paths=Module._nodeModulePaths(path.dirname(ef));em._compile(fs.readFileSync(ef,'utf8').replace('CFG, Piece, radU, norm,','CFG, Piece, radU, norm, resolvePush,'),ef);const exact=em.exports.createEngine();out.enginePushChecks=[];
for(const u of out.updates){const a=Object.assign(new exact.Piece(0),tie.attacker),v=Object.assign(new exact.Piece(1),tie.victim,{x:tie.victim.x+u.off});exact.resolvePush(a,v);out.enginePushChecks.push({off:u.off,x:v.x,y:v.y,rot:v.rot,gap:closest(a,v).dist-D,errorToReproduction:Math.hypot(v.x-u.final.x,v.y-u.final.y,R*(v.rot-u.final.rot))});}
const phases=JSON.parse(fs.readFileSync(__dirname+'/phase-check.json'));
for(const si of [0,1,2,4,8]){const spin=phases.spins[si];if(!spin)continue;const reps=spin.rows.filter((r,i)=>i===0||JSON.stringify(r.crossed)!==JSON.stringify(spin.rows[i-1].crossed)).slice(0,3);
 for(const r of reps){const seed=spin.name==='six'?[2.6627,33.2224,2.2687]:[.8192,-30.3367,-3.2227],ps=F.piecesOf([...seed,r.pose.x,r.pose.y,r.pose.rot]);const direct=F.limitLadder(ps,1,spin.pv,1);out.phaseChecks.push({name:spin.name,pv:spin.pv,P:spin.P,pose:r.pose,oracleDeg:r.lim,engineDeg:direct.lim*180/Math.PI,crossed:direct.crossed});}
}
fs.writeFileSync(__dirname+'/checks.json',JSON.stringify(out,null,2));console.log(JSON.stringify({contacts:out.contacts,updateJump:out.updateJump,updates:out.updates.map(r=>({off:r.off,finalGap:r.finalGap,final:r.final})),phaseChecks:out.phaseChecks},null,2));
